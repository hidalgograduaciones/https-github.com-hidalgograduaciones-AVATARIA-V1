
import express from 'express';
import { musicQueue, createMusicJob } from '../jobs/musicQueue.js';
import { systemHealth } from '../services/healthcheck.js';

const router = express.Router();

router.post('/command', async (req, res) => {
  const { command, payload } = req.body;
  
  if (command !== 'GENERATE_MUSIC') {
    return res.status(400).json({ status: 'ERROR', message: 'Comando inválido' });
  }

  try {
    const health = await systemHealth();
    // Permitir ejecución incluso si ffprobe falta, pero advertir
    if (!health.python || !health.musicgen) {
        return res.status(503).json({ 
            status: 'ERROR', 
            message: 'Motor de IA no disponible.', 
            details: health 
        });
    }

    const jobId = await createMusicJob(payload);
    return res.json({ status: 'QUEUED', jobId });
  } catch (err) {
    const isRedisError = err.message === 'REDIS_OFFLINE';
    return res.status(isRedisError ? 503 : 500).json({ 
        status: 'ERROR', 
        message: isRedisError ? 'Base de datos de colas fuera de línea.' : 'Error interno.' 
    });
  }
});

router.get('/job/:id', async (req, res) => {
  try {
    const job = await musicQueue.getJob(req.params.id);
    if (!job) return res.status(404).json({ status: 'NOT_FOUND' });

    const state = await job.getState();
    if (state === 'completed') {
      return res.json({ 
          status: 'COMPLETE', 
          phase: 'DELIVER_TRACK', 
          progress: 100, 
          result: { ...job.returnvalue, file: job.id }
      });
    }

    if (state === 'failed') return res.json({ status: 'ERROR', error: job.failedReason });

    return res.json({ 
        status: 'RUNNING', 
        phase: state === 'active' ? 'NEURAL_SYNTHESIS' : 'INIT', 
        progress: state === 'active' ? 60 : 10 
    });
  } catch (err) {
    res.status(500).json({ status: 'ERROR', message: err.message });
  }
});

export default router;
