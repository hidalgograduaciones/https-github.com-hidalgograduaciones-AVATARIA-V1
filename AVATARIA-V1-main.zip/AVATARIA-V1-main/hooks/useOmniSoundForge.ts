
import { useState, useCallback, useRef, useEffect } from "react";
import { 
    startGenerationJob, 
    checkJobStatus, 
    GenerateMusicCommand, 
    JobStatus, 
    ForgePhase,
    MusicStem,
    ForgeResult as ServiceForgeResult
} from "../services/arquiService";

export type ForgeResult = {
  trackUrl: string;
  coverArtUrl: string;
  title: string;
  bpm: number;
  key: string;
  mood: string;
  stems: MusicStem[];
  waveformData: number[];
  generatedAt: string;
};

type State = {
  status: JobStatus | "IDLE";
  progress: number;
  phase: ForgePhase;
  message: string;
  result?: ForgeResult;
  file?: string;
  mocked?: boolean;
};

const enrichVisuals = (audioId: string, audioPath: string, prompt: string): ForgeResult => ({
    trackUrl: audioPath || `/api/tracks/${audioId}/track.wav`,
    coverArtUrl: 'https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?q=80&w=1000&auto=format&fit=crop',
    title: 'FORJA NEURAL: ' + prompt.toUpperCase(),
    bpm: 124,
    key: 'D Minor',
    mood: 'Cyberpunk Atmospheric',
    stems: [
      { id: 's1', name: 'Neural Kick', type: 'DRUMS', color: 'bg-blue-500', volume: 90 },
      { id: 's2', name: 'Sub Bass', type: 'BASS', color: 'bg-purple-500', volume: 80 },
      { id: 's3', name: 'Arp Synth', type: 'MELODY', color: 'bg-pink-500', volume: 70 },
      { id: 's4', name: 'Void FX', type: 'FX', color: 'bg-yellow-500', volume: 60 },
    ],
    waveformData: Array.from({ length: 64 }, () => Math.floor(Math.random() * 50) + 30),
    generatedAt: new Date().toISOString()
});

export function useOmniSoundForge() {
  const [state, setState] = useState<State>({ 
      status: "IDLE", 
      progress: 0, 
      phase: "INIT", 
      message: "Ready to Forge" 
  });
  
  const pollingRef = useRef<number | null>(null);

  const stopPolling = () => {
      if (pollingRef.current) {
          window.clearInterval(pollingRef.current);
          pollingRef.current = null;
      }
  };

  const generate = useCallback(async (payload: GenerateMusicCommand) => {
    stopPolling();
    setState({ status: "QUEUED", progress: 0, phase: "INIT", message: "Sincronizando con el Núcleo..." });

    try {
        const initRes = await startGenerationJob(payload);
        const jobId = initRes.jobId;
        
        setState(s => ({ ...s, status: "QUEUED", message: "En cola de espera..." }));

        pollingRef.current = window.setInterval(async () => {
            try {
                const jobState = await checkJobStatus(jobId);

                if (jobState.status === "COMPLETE") {
                    stopPolling();
                    const resultData = jobState.result as any;
                    const audioPath = resultData?.audioPath || resultData?.trackUrl || `/api/tracks/${jobId}/track.wav`;
                    const finalResult = enrichVisuals(jobId, audioPath, payload.prompt);

                    setState({
                        status: "COMPLETE",
                        phase: "DELIVER_TRACK",
                        progress: 100,
                        message: "Sincronización Completada.",
                        file: jobId,
                        result: finalResult
                    });
                } else if (jobState.status === "ERROR") {
                    stopPolling();
                    setState(s => ({ ...s, status: "ERROR", message: jobState.error || "Fallo en la síntesis." }));
                } else {
                    setState(prev => ({
                        ...prev,
                        status: jobState.status,
                        phase: jobState.phase,
                        progress: jobState.progress || 0,
                        message: jobState.message || (jobState.phase === 'NEURAL_SYNTHESIS' ? 'Sintetizando audio IA...' : 'Procesando...')
                    }));
                }
            } catch (err) {
                console.error("Polling error:", err);
            }
        }, 1500);

    } catch (e: any) {
        stopPolling();
        setState(s => ({ ...s, status: "ERROR", message: "Error de red: Arqui no responde." }));
    }
  }, []);

  useEffect(() => {
      return () => stopPolling();
  }, []);

  return { ...state, generate };
}
