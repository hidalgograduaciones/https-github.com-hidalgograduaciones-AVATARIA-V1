import { useEffect, useState } from 'react';

export interface TrackDNA {
  id: string;
  prompt: string;
  style: string;
  duration: number;
  createdAt: string;
  dnaVersion: string;
  engine: string;
  specs: {
    format: string;
    sampleRate: number;
    channels: number;
  };
}

export const useTrackDNA = (jobId: string | undefined | null) => {
  const [dna, setDna] = useState<TrackDNA | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!jobId) {
        setDna(null);
        return;
    }

    setLoading(true);
    setError(null);

    fetch(`/api/tracks/${jobId}/metadata.json`)
      .then((res) => {
        if (!res.ok) throw new Error("DNA not found");
        return res.json();
      })
      .then((data: TrackDNA) => {
        setDna(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error("Failed to fetch Track DNA:", err);
        setError(err.message);
        setLoading(false);
      });
  }, [jobId]);

  return { dna, loading, error };
};