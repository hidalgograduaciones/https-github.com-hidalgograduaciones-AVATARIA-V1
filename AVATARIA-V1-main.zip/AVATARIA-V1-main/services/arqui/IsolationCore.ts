export const IsolationCore = {
  identidad: "ARQUI_4",
  aislar(obj: any) {
    obj.identidad = this.identidad;
    return obj;
  }
};