import { useState, useEffect, useRef } from 'react';
import {
  generateMusic,
  getMusicJob,
  GenerateMusicPayload,
  MusicJobResponse,
  JobPhase
} from '../services/musicService';

type Status =
  | 'IDLE'
  | 'SYNCING'
  | 'SEEDING'
  | 'COMPOSING'
  | 'MASTERING'
  | 'FINALIZING'
  | 'SUCCESS'
  | 'ERROR';

export const useMusicGenerator = () => {
  const [status, setStatus] = useState<Status>('IDLE');
  const [progress, setProgress] = useState<number>(0);
  const [jobId, setJobId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [cost, setCost] = useState<number | null>(null);
  
  // FIX #1: Correct type for browser interval
  const pollingRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // FIX #4: Strict Typing for Map
  const phaseToStatusMap: Record<JobPhase, Status> = {
    SYNCING: 'SYNCING',
    SEEDING: 'SEEDING',
    COMPOSING: 'COMPOSING',
    MASTERING: 'MASTERING',
    FINALIZING: 'FINALIZING',
  };

  const clearPolling = () => {
    if (pollingRef.current) {
      clearInterval(pollingRef.current);
      pollingRef.current = null;
    }
  };

  const pollJob = (jobId: string) => {
    pollingRef.current = setInterval(async () => {
      try {
        // FIX #3: Error handling inside polling
        const job: MusicJobResponse = await getMusicJob(jobId);

        setProgress(job.progress);
        if (job.cost) setCost(job.cost.omniCoins);
        
        // Map backend phase to frontend status
        setStatus(phaseToStatusMap[job.phase] || 'SYNCING');

        if (job.status === 'SUCCESS' && job.data) {
          clearPolling();
          setAudioUrl(job.data.audioUrl);
          setStatus('SUCCESS');
        }

        if (job.status === 'ERROR') {
          clearPolling();
          setError(job.error?.message || 'Error desconocido en el núcleo.');
          setStatus('ERROR');
        }
      } catch (e) {
         clearPolling();
         setError('Distorsión en el enlace neural. Conexión perdida.');
         setStatus('ERROR');
      }
    }, 700);
  };

  const generate = async (payload: GenerateMusicPayload) => {
    // FIX #2: Prevent duplicate polling
    clearPolling();
    
    setStatus('SYNCING');
    setProgress(0);
    setError(null);
    setAudioUrl(null);
    setCost(null);

    try {
        const response = await generateMusic(payload);

        if (response.status === 'ACCEPTED') {
        setJobId(response.jobId);
        setStatus(phaseToStatusMap[response.phase] || 'SYNCING');
        setProgress(response.progress);
        if (response.cost) setCost(response.cost.omniCoins);
        pollJob(response.jobId);
        } else if (response.status === 'ERROR') {
        setError(response.error?.message || 'Error al iniciar generación');
        setStatus('ERROR');
        }
    } catch (e) {
        setError('Error crítico al contactar OmniSound.');
        setStatus('ERROR');
    }
  };

  useEffect(() => {
    return () => clearPolling();
  }, []);

  return {
    status,
    progress,
    error,
    audioUrl,
    cost,
    generate,
  };
};