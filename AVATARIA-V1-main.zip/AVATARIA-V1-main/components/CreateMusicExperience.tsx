import React, { useState, useRef, useEffect } from 'react';
import { useOmniSoundForge } from '../hooks/useOmniSoundForge';
import { useTrackDNA } from '../hooks/useTrackDNA';
import { 
    Play, Pause, Music, AlertTriangle, CheckCircle2, 
    Zap, Layers, Wand2, Database, Speaker, Radio, 
    Sliders, Activity, Disc, Share2, Download, Loader2,
    Fingerprint
} from 'lucide-react';
import { ForgePhase } from '../services/arquiService';

const mockUserId = "user-omnicorp-001";

export const CreateMusicExperience: React.FC = () => {
  const { status, phase, progress, message, result, file, mocked, generate } = useOmniSoundForge();
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);
  
  // Hook de ADN: Solo intenta fetchear si tenemos un file ID (status COMPLETE)
  const { dna, loading: dnaLoading } = useTrackDNA(file);

  // Auto-load audio on success
  useEffect(() => {
    if (status === "COMPLETE" && result?.trackUrl && audioRef.current) {
      audioRef.current.load();
      setIsPlaying(false);
    }
  }, [status, result?.trackUrl]);

  const handleClick = () => {
    if (status === 'QUEUED' || status === 'RUNNING') return;
    generate({
      userId: mockUserId,
      prompt: "cyberpunk synthwave with atmospheric pads",
      duration: 10, // Default corto para pruebas rápidas
      style: "Electronic/Synth"
    });
  };

  const togglePlay = () => {
    if (!audioRef.current) return;
    
    if (isPlaying) {
        audioRef.current.pause();
    } else {
        const p = audioRef.current.play();
        if (p !== undefined) {
            p.catch(err => {
                console.warn("Playback interrupted:", err);
                setIsPlaying(false);
            });
        }
    }
  };

  const handleDownload = () => {
      // DESCARGA REAL
      if (file) {
          // Usa el endpoint de exportación que fuerza Content-Disposition
          window.open(`/api/export/${file}`, "_self");
      }
  };

  const renderPhaseIcon = (p: ForgePhase) => {
      switch(p) {
          case 'INIT': return <Database className="animate-pulse text-gray-500" size={32} />;
          case 'SYNC_CORE': return <Loader2 className="animate-spin text-blue-500" size={32} />;
          case 'NEURAL_SYNTHESIS': return <Wand2 className="animate-bounce text-purple-500" size={32} />;
          case 'COMPOSE_STRUCTURE': return <Layers className="animate-pulse text-pink-500" size={32} />;
          case 'MASTERING': return <Activity className="animate-pulse text-yellow-500" size={32} />;
          case 'DELIVER_TRACK': return <CheckCircle2 className="text-green-500" size={32} />;
          default: return <Disc className="text-gray-700" size={32} />;
      }
  };

  const isProcessing = status === 'QUEUED' || status === 'RUNNING';

  // --- VISTA DE PROCESAMIENTO ---
  if (status !== 'COMPLETE') {
    return (
        <div className="flex flex-col items-center justify-center h-full w-full animate-fade-in relative">
            <div className={`absolute inset-0 overflow-hidden pointer-events-none transition-all duration-1000 ${isProcessing ? 'opacity-100' : 'opacity-30'}`}>
                <div className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full blur-[120px] ${status === 'ERROR' ? 'bg-red-900/20' : 'bg-purple-900/20'}`}></div>
            </div>

            <div className="relative z-10 w-full max-w-lg bg-black/60 backdrop-blur-xl border border-gray-800 rounded-3xl p-10 shadow-2xl ring-1 ring-white/5">
                <div className="flex items-center justify-center mb-10">
                    <div className="p-4 bg-black/50 rounded-full border border-gray-800 shadow-[0_0_30px_rgba(139,92,246,0.15)]">
                        {renderPhaseIcon(phase)}
                    </div>
                </div>
                
                <h2 className="text-3xl font-black text-center text-white mb-2 tracking-tight">OMNISOUND <span className="text-omni-accent">FORGE</span></h2>
                <p className="text-center text-gray-400 font-light mb-8">
                    {isProcessing ? 'Sincronizando con Núcleo Neural...' : 'Motor de síntesis de alta fidelidad.'}
                </p>

                {isProcessing ? (
                     <div className="space-y-4">
                        <div className="flex justify-between text-xs font-mono text-gray-400 uppercase tracking-widest">
                            <span>{message}</span>
                            <span>{status === 'QUEUED' ? 'Q' : Math.round(progress)}%</span>
                        </div>
                        <div className="w-full h-1.5 bg-gray-800 rounded-full overflow-hidden relative">
                            <div className="h-full bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 transition-all duration-300" style={{ width: `${progress}%` }}></div>
                            <div className="absolute right-0 top-0 h-full w-20 bg-white/40 blur-[8px]" style={{ left: `${progress}%` }}></div>
                        </div>
                     </div>
                ) : (
                    <button
                        onClick={handleClick}
                        className="group w-full py-5 rounded-2xl bg-white text-black font-black tracking-widest hover:bg-gray-200 transition-all duration-300 shadow-[0_0_20px_rgba(255,255,255,0.2)] hover:shadow-[0_0_30px_rgba(255,255,255,0.4)] flex items-center justify-center gap-3"
                    >
                        INICIAR SECUENCIA <Zap className="group-hover:text-yellow-600 transition-colors" size={20} fill="currentColor" />
                    </button>
                )}
                 {status === 'ERROR' && (
                    <div className="mt-4 p-3 bg-red-900/30 border border-red-800 rounded-lg text-red-200 text-xs text-center font-mono flex items-center justify-center gap-2">
                        <AlertTriangle size={14} /> {message}
                    </div>
                )}
            </div>
        </div>
    );
  }

  // --- VISTA GOD-LEVEL RESULT (COMPLETE) ---
  return (
    <div className="h-full w-full flex flex-col animate-fade-in gap-6 max-w-7xl mx-auto">
        {/* Top Header */}
        <div className="flex items-center justify-between">
            <h2 className="text-2xl font-black text-white flex items-center gap-3">
                <Music className="text-purple-500" />
                MASTERING CONSOLE
            </h2>
            <div className="flex gap-2">
                <button onClick={handleClick} className="px-4 py-2 bg-gray-800 hover:bg-gray-700 rounded-lg text-xs font-bold text-white transition-colors border border-gray-700">
                    NUEVO PROYECTO
                </button>
                <button 
                    onClick={handleDownload}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-500 rounded-lg text-xs font-bold text-white transition-colors shadow-lg shadow-blue-900/50 flex items-center gap-2"
                >
                    <Download size={14} /> DESCARGAR WAV
                </button>
            </div>
        </div>

        <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-6 min-h-0">
            
            {/* LEFT COL: COVER ART & PLAYBACK */}
            <div className="lg:col-span-4 flex flex-col gap-6">
                <div className="bg-black/40 border border-gray-800 rounded-2xl p-6 relative overflow-hidden group">
                     <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/80 z-10"></div>
                     <img 
                        src={result?.coverArtUrl} 
                        alt="Cover Art" 
                        className="w-full aspect-square object-cover