import { exec } from 'child_process';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export const checkPython = () => {
  return new Promise((resolve) => {
    exec('python3 --version', (err) => {
      resolve(!err);
    });
  });
};

export const checkMusicGen = () => {
  // Check for the service script instead of the runner
  const scriptPath = path.resolve(__dirname, '../scripts/musicgen_service.py');
  return Promise.resolve(fs.existsSync(scriptPath));
};

export const checkAudioTools = () => {
  return new Promise((resolve) => {
    exec('ffprobe -version', (err) => {
      resolve(!err);
    });
  });
};

export const systemHealth = async () => {
  const checks = await Promise.all([
    checkPython(),
    checkMusicGen(),
    checkAudioTools(),
  ]);

  return {
    python: checks[0],
    musicgen: checks[1],
    ffprobe: checks[2],
    all: checks.every(Boolean),
  };
};