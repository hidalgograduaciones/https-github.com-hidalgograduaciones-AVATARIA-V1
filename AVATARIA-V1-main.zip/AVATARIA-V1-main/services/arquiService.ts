
import axios from "axios";

export type JobStatus = "QUEUED" | "RUNNING" | "COMPLETE" | "ERROR" | "IDLE";

export type ForgePhase =
  | "INIT"
  | "SYNC_CORE"
  | "NEURAL_SYNTHESIS"
  | "COMPOSE_STRUCTURE"
  | "MASTERING"
  | "DELIVER_TRACK";

export type MusicStem = {
  id: string;
  name: string;
  type: string;
  color: string;
  volume: number;
};

export interface ForgeResult {
  audioPath?: string;
  audioUrl?: string;
  trackUrl?: string;
  file?: string;
  mocked?: boolean;
  title?: string;
  bpm?: number;
  key?: string;
  mood?: string;
  stems?: MusicStem[];
  waveformData?: number[];
  coverArtUrl?: string;
}

export type GenerateMusicCommand = {
  userId: string;
  prompt: string;
  style?: string;
  duration?: number;
};

export type JobStateResponse = {
    status: JobStatus;
    phase: ForgePhase;
    progress: number;
    result?: ForgeResult;
    error?: string;
    message?: string;
    jobId?: string;
};

const BASE_API = "/api/arqui";

export async function startGenerationJob(payload: GenerateMusicCommand): Promise<{status: string, jobId: string, message?: string}> {
  const res = await axios.post(`${BASE_API}/command`, {
    command: "GENERATE_MUSIC",
    payload,
  });
  return res.data;
}

export async function checkJobStatus(jobId: string): Promise<JobStateResponse> {
    const res = await axios.get(`${BASE_API}/job/${jobId}`);
    return res.data;
}
