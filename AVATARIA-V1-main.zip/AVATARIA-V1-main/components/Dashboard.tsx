
import React from 'react';
import { Mic2, Fingerprint, Cpu, Globe, Activity, TrendingUp, Zap, Server } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const statsData = [
  { name: 'M1', activity: 4200 },
  { name: 'M2', activity: 3100 },
  { name: 'M3', activity: 5800 },
  { name: 'M4', activity: 2100 },
];

const Dashboard: React.FC = () => {
  return (
    <div className="space-y-12 animate-fade-in">
      {/* MONOLITHIC WELCOME */}
      <div className="relative bg-zinc-900 border border-zinc-800 rounded-[40px] p-12 shadow-2xl overflow-hidden group">
        <div className="absolute top-0 right-0 w-96 h-96 bg-omni-accent/5 rounded-full blur-[100px] -mr-32 -mt-32 group-hover:bg-omni-accent/10 transition-colors duration-1000"></div>
        <div className="relative z-10">
          <h2 className="text-6xl font-black text-white mb-4 tracking-tighter leading-none">SYSTEMS <span className="text-zinc-700">INTEGRATED.</span></h2>
          <p className="text-zinc-500 max-w-2xl text-xl font-light leading-relaxed">
            OmniCorp Unified Architecture V4.0.0. All sovereign modules are now synchronized with the Gemini Neural Core. 
          </p>
        </div>
      </div>

      {/* WORLD INFRASTRUCTURE */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { id: 'M1', label: 'Creación', icon: Mic2, color: 'purple', status: 'ONLINE', desc: 'Neural Audio Synthesizer' },
          { id: 'M2', label: 'Identidad', icon: Fingerprint, color: 'pink', status: 'STABLE', desc: 'Avatar Materializer' },
          { id: 'M3', label: 'Agentes', icon: Cpu, color: 'blue', status: 'EXECUTION', desc: 'Arkhe Core Intelligence' },
          { id: 'M4', label: 'Experiencia', icon: Globe, color: 'yellow', status: 'STANDBY', desc: 'OmniWorld Metaverse' },
        ].map((world) => (
          <div key={world.id} className="bg-zinc-900 border border-zinc-800 p-8 rounded-3xl hover:border-zinc-600 transition-all group relative overflow-hidden">
            <world.icon className={`absolute -top-4 -right-4 size-24 opacity-5 text-${world.color}-500 group-hover:opacity-10 transition-opacity`} />
            <div className="relative z-10">
              <span className={`text-[10px] font-mono text-${world.color}-400 uppercase tracking-widest font-black`}>{world.id}</span>
              <h3 className="text-2xl font-black text-white mt-2">{world.label}</h3>
              <p className="text-xs text-zinc-500 mt-2 font-mono">{world.desc}</p>
              <div className="mt-8 flex items-center justify-between border-t border-zinc-800 pt-4">
                 <div className="flex items-center gap-2">
                    <div className={`w-1.5 h-1.5 rounded-full bg-${world.color}-500 shadow-[0_0_8px_${world.color === 'blue' ? '#3b82f6' : world.color}] animate-pulse`} />
                    <span className={`text-[9px] font-black text-${world.color}-400 font-mono tracking-widest`}>{world.status}</span>
                 </div>
                 <Zap size={12} className="text-zinc-800" />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* ANALYTICS BLOCK */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-zinc-900 border border-zinc-800 p-10 rounded-[32px]">
            <h3 className="text-sm font-black text-zinc-500 mb-10 flex items-center gap-4 uppercase tracking-[0.2em]">
                <Activity size={18} className="text-omni-accent"/> Inter-World Synaptic Flow
            </h3>
            <div className="h-80 w-full">
                <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={statsData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#18181b" vertical={false} />
                        <XAxis dataKey="name" stroke="#3f3f46" tickLine={false} axisLine={false} fontSize={10} fontStyle="italic" />
                        <YAxis stroke="#3f3f46" tickLine={false} axisLine={false} fontSize={10} />
                        <Tooltip 
                            contentStyle={{ backgroundColor: '#09090b', border: '1px solid #27272a', borderRadius: '16px' }}
                            itemStyle={{ color: '#fff', fontSize: '10px', textTransform: 'uppercase', fontFamily: 'monospace' }}
                            cursor={{ fill: '#ffffff05' }}
                        />
                        <Bar dataKey="activity" fill="#3b82f6" radius={[6, 6, 6, 6]} barSize={50} />
                    </BarChart>
                </ResponsiveContainer>
            </div>
        </div>

        <div className="bg-zinc-950 border border-zinc-900 p-10 rounded-[32px] flex flex-col justify-center relative overflow-hidden">
             <div className="absolute top-0 right-0 p-10 text-zinc-900 opacity-20"><Server size={80} /></div>
             <div className="text-center relative z-10">
                <div className="inline-flex items-center justify-center w-20 h-20 rounded-[24px] bg-omni-success/5 text-omni-success mb-6 border border-omni-success/10">
                    <TrendingUp size={36} />
                </div>
                <h3 className="text-5xl font-black text-white tracking-tighter">99.98%</h3>
                <p className="text-[10px] text-zinc-600 uppercase tracking-[0.4em] mt-2 font-mono">Neural Efficiency</p>
             </div>
             <div className="mt-12 space-y-6">
                <div className="space-y-2">
                    <div className="flex justify-between text-[9px] font-mono text-zinc-500 uppercase tracking-widest">
                        <span>CORE_AVAILABILITY</span>
                        <span>SVRGN</span>
                    </div>
                    <div className="h-1 bg-zinc-900 rounded-full overflow-hidden">
                        <div className="h-full bg-omni-accent w-[92%] transition-all duration-300 shadow-[0_0_10px_#3b82f6]"></div>
                    </div>
                </div>
                <div className="space-y-2">
                    <div className="flex justify-between text-[9px] font-mono text-zinc-500 uppercase tracking-widest">
                        <span>ARQUI_PERSISTENCE</span>
                        <span>STABLE</span>
                    </div>
                    <div className="h-1 bg-zinc-900 rounded-full overflow-hidden">
                        <div className="h-full bg-omni-purple w-[100%] transition-all duration-300 shadow-[0_0_10px_#8b5cf6]"></div>
                    </div>
                </div>
             </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
