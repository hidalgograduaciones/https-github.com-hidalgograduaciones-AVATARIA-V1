
import React, { useState, useEffect, useRef } from 'react';
import { Send, Cpu, ShieldCheck, Database, Activity, Terminal as TerminalIcon } from 'lucide-react';
import { Arqui } from '../libs/arqui/arqui-core';

interface LogEntry {
  type: 'user' | 'system';
  content: string;
  timestamp: string;
}

const ArquiTerminal: React.FC = () => {
  const [input, setInput] = useState('');
  const [logs, setLogs] = useState<LogEntry[]>([
    { type: 'system', content: 'ARKHE CORE V4.0.0_SVRGN INITIALIZED.', timestamp: new Date().toLocaleTimeString() },
    { type: 'system', content: 'ISOLATION_PROTOCOL: ACTIVE (libs/arqui).', timestamp: new Date().toLocaleTimeString() },
    { type: 'system', content: 'AWAITING COMMANDS...', timestamp: new Date().toLocaleTimeString() }
  ]);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(scrollToBottom, [logs]);

  const handleExecute = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim()) return;

    const currentInput = input;
    setInput('');

    const newLogs: LogEntry[] = [...logs, {
      type: 'user',
      content: currentInput,
      timestamp: new Date().toLocaleTimeString()
    }];

    let command = "general_command";
    let data: any = { raw: currentInput };

    const lower = currentInput.toLowerCase();
    if (lower.includes("create") && lower.includes("room")) command = "crear_salon";
    else if (lower.includes("table")) command = "agregar_mesas";
    else if (lower.includes("chair")) command = "agregar_sillas";
    else if (lower.includes("status")) command = "status";
    else if (lower.includes("help")) command = "ayuda";
    else if (lower.includes("dump")) command = "dump_state";

    const response = Arqui.procesar(command, data);

    newLogs.push({
      type: 'system',
      content: response.resultado,
      timestamp: new Date().toLocaleTimeString()
    });

    setLogs(newLogs);
  };

  return (
    <div className="flex flex-col h-full bg-zinc-950/80 rounded-3xl border border-zinc-900 overflow-hidden font-mono text-xs shadow-2xl backdrop-blur-md">
      <div className="bg-zinc-900/50 px-6 py-4 border-b border-zinc-900 flex items-center justify-between">
        <div className="flex items-center gap-3 text-omni-accent">
          <TerminalIcon size={14} />
          <span className="font-black tracking-widest text-[10px]">ARKHE_TERMINAL</span>
        </div>
        <div className="flex items-center gap-4 opacity-50">
          <ShieldCheck size={12} className="text-omni-success" />
          <Database size={12} className="text-omni-purple" />
          <Activity size={12} className="text-yellow-500" />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-8 space-y-6 custom-scrollbar">
        {logs.map((log, index) => (
          <div key={index} className={`flex flex-col ${log.type === 'user' ? 'items-end' : 'items-start'}`}>
            <div className={`max-w-[85%] rounded-2xl p-4 ${
              log.type === 'user' 
                ? 'bg-omni-accent/10 text-omni-accent border border-omni-accent/20' 
                : 'bg-zinc-900 text-zinc-400 border border-zinc-800'
            }`}>
              <div className="flex items-center gap-3 mb-2 opacity-30 text-[9px] font-black tracking-widest">
                 <span>{log.type === 'user' ? 'USER_STIMULUS' : 'CORE_EXECUTION'}</span>
                 <span>{log.timestamp}</span>
              </div>
              <div className="whitespace-pre-wrap leading-relaxed">{log.content}</div>
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      <form onSubmit={handleExecute} className="p-4 bg-zinc-900/30 border-t border-zinc-900 flex gap-4">
        <div className="flex-1 bg-black/50 rounded-xl px-4 py-3 flex items-center border border-zinc-800 focus-within:border-omni-accent transition-colors">
          <span className="text-omni-accent mr-3 font-black">{'>'}</span>
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="AWAITING COMMANDS..."
            className="flex-1 bg-transparent border-none outline-none text-zinc-200 placeholder-zinc-800 font-mono text-xs"
            autoFocus
          />
        </div>
        <button 
          type="submit"
          disabled={!input.trim()}
          className="px-6 bg-omni-accent text-white font-black rounded-xl text-[10px] hover:bg-blue-600 disabled:opacity-20 transition-all uppercase tracking-widest"
        >
          SEND
        </button>
      </form>
    </div>
  );
};

export default ArquiTerminal;
