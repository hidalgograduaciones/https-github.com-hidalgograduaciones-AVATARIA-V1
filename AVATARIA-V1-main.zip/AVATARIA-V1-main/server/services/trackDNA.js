import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export const writeTrackMetadata = (jobId, metadata) => {
  // Path relative to services folder: ../storage/tracks
  const folder = path.resolve(__dirname, `../storage/tracks/${jobId}`);
  if (!fs.existsSync(folder)) fs.mkdirSync(folder, { recursive: true });

  const data = {
    ...metadata,
    createdAt: metadata.createdAt || new Date().toISOString(),
    version: 1,
    stems: {
      available: false,
    },
    dnaVersion: "1.0",
    engine: "OmniSound Core V1"
  };

  fs.writeFileSync(path.join(folder, 'metadata.json'), JSON.stringify(data, null, 2));
};
