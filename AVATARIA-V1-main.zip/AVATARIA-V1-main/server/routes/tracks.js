import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const router = express.Router();

// Servir Audio
router.get('/tracks/:id/track.wav', (req, res) => {
  const file = path.resolve(__dirname, `../storage/tracks/${req.params.id}/track.wav`);
  if (!fs.existsSync(file)) return res.status(404).send('Not found');
  
  res.setHeader('Content-Type', 'audio/wav');
  res.setHeader('Accept-Ranges', 'bytes');
  res.sendFile(file);
});

// Servir Metadata
router.get('/tracks/:id/metadata', (req, res) => {
  const file = path.resolve(__dirname, `../storage/tracks/${req.params.id}/metadata.json`);
  if (!fs.existsSync(file)) return res.status(404).send('Not found');
  
  const data = fs.readFileSync(file, 'utf-8');
  res.setHeader('Content-Type', 'application/json');
  res.json(JSON.parse(data));
});

// Endpoint de Exportación (Descarga forzada)
router.get("/export/:id", (req, res) => {
    const jobId = req.params.id;
    const filePath = path.resolve(__dirname, `../storage/tracks/${jobId}/track.wav`);
    
    if (!fs.existsSync(filePath)) return res.status(404).send("Export failed: File missing.");

    res.setHeader("Content-Type", "audio/wav");
    res.setHeader("Content-Disposition", `attachment; filename="OMNI_TRACK_${jobId}.wav"`);
    res.sendFile(filePath);
});

export default router;
