import { StabilityCore } from "./StabilityCore";
import { MemoryEngine } from "./MemoryEngine";

export const CommandExecutor = {
  ejecutar(orden: string, datos?: any) {
    switch (orden) {
      case "crear_salon":
        MemoryEngine.set("salon", datos);
        return StabilityCore.enforce("Salón creado.");
      case "agregar_mesas":
        MemoryEngine.push("mobiliario", { tipo: "mesa", ...datos });
        return StabilityCore.enforce("Mesas agregadas.");
      case "agregar_sillas":
        MemoryEngine.push("mobiliario", { tipo: "silla", ...datos });
        return StabilityCore.enforce("Sillas agregadas.");
      case "status":
        const mem = MemoryEngine.data;
        return StabilityCore.enforce(`Estado del Sistema:\nSalón: ${JSON.stringify(mem.salon)}\nMobiliario: ${mem.mobiliario.length} items.`);
      case "ayuda":
         return StabilityCore.enforce("Comandos: crear_salon, agregar_mesas, agregar_sillas, status.");
      default:
        // Default safe fallback if command unknown, standard Arqui 4 behavior: Execute & Enforce
        return StabilityCore.enforce("Orden recibida. Ejecutando protocolo estándar.");
    }
  }
};