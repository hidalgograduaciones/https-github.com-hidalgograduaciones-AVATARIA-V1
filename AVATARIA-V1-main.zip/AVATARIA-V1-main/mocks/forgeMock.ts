import { GenerateMusicCommand, ForgePhase, ForgeResult, JobStateResponse as ArquiResponse } from '../services/arquiService';

// --- MOCK SERVER STATE ---
// Almacén en memoria para simular persistencia de jobs durante polling
const jobStore = new Map<string, ArquiResponse>();
const activeTimers = new Set<ReturnType<typeof setInterval>>();

const phases: ForgePhase[] = [
  'SYNC_CORE',
  'COMPOSE_STRUCTURE',
  'NEURAL_SYNTHESIS',
  'MASTERING',
  'DELIVER_TRACK',
];

// Generador de datos fake God-Level
const generateRichResult = (): ForgeResult => ({
  trackUrl: 'https://assets.mixkit.co/music/preview/mixkit-synthwave-80s-132.mp3',
  // Note: UI-only fields like coverArtUrl are enriched in the hook or handled via optional extension
  // Fixing the error where coverArtUrl was incorrectly assigned to ForgeResult which doesn't have it.
  title: 'NEON HORIZON PROTOCOL',
  bpm: 128,
  key: 'C# Minor',
  mood: 'Energetic / Cyberpunk',
  stems: [
    { id: 's1', name: 'Kick & Snare', type: 'DRUMS', color: 'bg-blue-500', volume: 90 },
    { id: 's2', name: 'Synth Bass', type: 'BASS', color: 'bg-purple-500', volume: 85 },
    { id: 's3', name: 'Arp Lead', type: 'MELODY', color: 'bg-pink-500', volume: 75 },
    { id: 's4', name: 'Atmosphere FX', type: 'FX', color: 'bg-yellow-500', volume: 60 },
  ],
  waveformData: Array.from({ length: 64 }, () => Math.floor(Math.random() * 80) + 20)
});

// Simula el proceso en el "backend"
const runMockPipeline = (jobId: string) => {
    let phaseIndex = 0;
    let progress = 0;

    const timer = setInterval(() => {
        const job = jobStore.get(jobId);
        if (!job) {
            clearInterval(timer);
            return;
        }

        // Simular avance
        progress += Math.floor(Math.random() * 10) + 5;
        
        // Cambio de fase basado en progreso
        if (progress < 20) phaseIndex = 0;
        else if (progress < 40) phaseIndex = 1;
        else if (progress < 60) phaseIndex = 2;
        else if (progress < 85) phaseIndex = 3;
        else phaseIndex = 4; // DELIVER

        if (progress >= 100) {
            // FIN DEL TRABAJO
            jobStore.set(jobId, {
                status: 'COMPLETE',
                jobId,
                phase: 'DELIVER_TRACK',
                progress: 100,
                message: 'Track forjado. Datos maestros transferidos.',
                result: generateRichResult()
            });
            clearInterval(timer);
            activeTimers.delete(timer);
        } else {
            // ACTUALIZACIÓN
            jobStore.set(jobId, {
                status: 'RUNNING',
                jobId,
                phase: phases[phaseIndex],
                progress,
                message: `Procesando fase: ${phases[phaseIndex]}...`
            });
        }
    }, 800);
    
    activeTimers.add(timer);
};

export const mockStartJob = async (
  _payload: GenerateMusicCommand
): Promise<ArquiResponse> => {
  // Simular latencia de red inicial
  await new Promise(r => setTimeout(r, 400));

  const jobId = `mock-job-${Date.now()}`;
  const initialResponse: ArquiResponse = {
      status: 'RUNNING',
      jobId,
      phase: 'SYNC_CORE',
      progress: 0,
      message: 'Inicializando simulación de forja...'
  };

  jobStore.set(jobId, initialResponse);
  
  // Arrancar proceso en background
  runMockPipeline(jobId);

  return initialResponse;
};

export const mockGetJob = async (jobId: string): Promise<ArquiResponse> => {
    // Simular latencia de red ligera
    await new Promise(r => setTimeout(r, 200));
    
    const job = jobStore.get(jobId);
    if (!job) {
        return { status: 'ERROR', message: 'Job not found in mock store', phase: 'INIT', progress: 0 };
    }
    return job;
};