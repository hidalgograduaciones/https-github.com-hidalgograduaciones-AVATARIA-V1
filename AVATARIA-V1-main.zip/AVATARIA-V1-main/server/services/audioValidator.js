import { exec } from 'child_process';
import fs from 'fs';

export const validateAudio = (filePath) => {
  return new Promise((resolve) => {
    if (!fs.existsSync(filePath)) return resolve(false);

    // Basic size check (> 10KB)
    const stats = fs.statSync(filePath);
    if (stats.size < 10240) {
        return resolve(false);
    }

    const cmd = `ffprobe -v error -show_entries format=duration -of csv=p=0 "${filePath}"`;
    exec(cmd, (err, stdout) => {
      if (err) {
        // Fallback: if ffprobe fails/missing, trust the size check
        return resolve(true);
      }
      const duration = parseFloat(stdout.trim());
      resolve(!isNaN(duration) && duration >= 3);
    });
  });
};
