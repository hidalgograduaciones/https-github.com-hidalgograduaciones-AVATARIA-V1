import React from 'react';
import { LayoutDashboard, Mic2, Fingerprint, Cpu, Globe, Settings, Layers } from 'lucide-react';
import { WorldView } from '../types';

interface SidebarProps {
  currentView: WorldView;
  setView: (view: WorldView) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentView, setView }) => {
  const menuItems = [
    { 
      id: WorldView.DASHBOARD, 
      label: 'Visión Global', 
      icon: LayoutDashboard,
      desc: 'Resumen del Ecosistema'
    },
    { 
      section: 'LOS 4 MUNDOS' 
    },
    { 
      id: WorldView.CREATION, 
      label: 'Mundo 1: Creación', 
      icon: Mic2,
      desc: 'OmniSound Engine' 
    },
    { 
      id: WorldView.IDENTITY, 
      label: 'Mundo 2: Identidad', 
      icon: Fingerprint,
      desc: 'Génesis / Avataría' 
    },
    { 
      id: WorldView.AGENTS, 
      label: 'Mundo 3: Agentes', 
      icon: Cpu,
      desc: 'Arkhé / Consola',
      special: true
    },
    { 
      id: WorldView.EXPERIENCE, 
      label: 'Mundo 4: Experiencia', 
      icon: Globe,
      desc: 'OmniWorld' 
    },
  ];

  return (
    <div className="w-72 bg-omni-panel border-r border-gray-800 flex flex-col h-full shadow-2xl z-50">
      <div className="p-6 border-b border-gray-800 bg-black/20">
        <h1 className="text-xl font-black tracking-tighter text-white flex items-center gap-2">
          <Layers className="text-omni-accent" />
          OMNICORP <span className="text-gray-600">IA</span>
        </h1>
        <p className="text-[10px] text-gray-500 mt-2 font-mono uppercase tracking-widest">
          Arquitectura Unificada
        </p>
      </div>

      <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
        {menuItems.map((item, index) => {
          if (item.section) {
            return (
              <div key={`section-${index}`} className="px-4 py-3 mt-4 mb-2">
                <span className="text-[10px] font-bold text-gray-600 uppercase tracking-widest">
                  {item.section}
                </span>
              </div>
            );
          }

          const Icon = item.icon!;
          const isActive = currentView === item.id;

          return (
            <button
              key={item.id}
              onClick={() => setView(item.id as WorldView)}
              className={`w-full group flex items-start gap-4 px-4 py-3 rounded-xl transition-all duration-300 border ${
                isActive
                  ? item.special 
                    ? 'bg-blue-900/20 border-blue-500/50 shadow-[0_0_15px_rgba(59,130,246,0.2)]' 
                    : 'bg-white/5 border-gray-700 shadow-lg'
                  : 'bg-transparent border-transparent hover:bg-white/5 hover:border-gray-800'
              }`}
            >
              <div className={`mt-1 p-2 rounded-lg transition-colors ${
                isActive ? 'bg-white text-black' : 'bg-gray-800 text-gray-400 group-hover:text-white'
              }`}>
                <Icon size={18} />
              </div>
              <div className="flex flex-col items-start">
                <span className={`text-sm font-bold ${isActive ? 'text-white' : 'text-gray-400 group-hover:text-gray-200'}`}>
                  {item.label}
                </span>
                <span className="text-[10px] text-gray-600 font-mono mt-0.5 group-hover:text-gray-500">
                  {item.desc}
                </span>
              </div>
            </button>
          );
        })}
      </nav>

      <div className="p-4 border-t border-gray-800 bg-black/20">
        <button className="flex items-center gap-3 px-4 py-3 text-gray-500 hover:text-white transition-colors w-full rounded-lg hover:bg-white/5">
          <Settings size={18} />
          <span className="text-xs font-medium uppercase tracking-wider">Ajustes del Sistema</span>
        </button>
      </div>
    </div>
  );
};

export default Sidebar;