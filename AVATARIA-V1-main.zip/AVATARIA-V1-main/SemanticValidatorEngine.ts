
export const WorldOntology = {
  estilos: {
    'CIBERPUNK': {
      id: "omnysound-001",
      musicaPermitida: ['Synthwave', 'Industrial', 'Dark Ambient', 'ambient', 'chillwave', 'electrónica etérea', 'lo-fi'],
      narrativa: ['distópico', 'tecnológico', 'caos', 'neón', 'orgánico-digital'],
      paletaColores: ['#ff00ff', '#00ffff', '#000000'],
      estabilidad: 0.8,
      restricciones: {
        musicaProhibida: ['Clásica', 'Lo-fi', 'Folk', 'metal extremo', 'ruido blanco'],
        objetosProhibidos: ['Velas de cera', 'Carruajes']
      },
    },
    'ZEN': {
      id: "claude-core",
      musicaPermitida: ['Lo-fi', 'Ambient', 'Acústico'],
      narrativa: ['calma', 'armonía', 'naturaleza', 'paz', 'analítico-creativo'],
      paletaColores: ['#f5f5dc', '#228b22', '#ffffff'],
      estabilidad: 0.95,
      restricciones: {
        musicaProhibida: ['Industrial', 'Dubstep', 'Heavy Metal'],
        objetosProhibidos: ['Pantallas gigantes', 'Armas láser']
      },
    },
    'BARROCO': {
      id: "arkhe-primordial",
      musicaPermitida: ['Clásica', 'Ópera', 'Coral'],
      narrativa: ['nobleza', 'historia', 'solemnidad', 'exceso', 'minimalista-estructural'],
      paletaColores: ['#ffd700', '#8b0000', '#ffffff'],
      estabilidad: 1.0,
      restricciones: {
        musicaProhibida: ['Synthwave', 'Trap', 'Techno'],
        objetosProhibidos: ['Robots', 'Circuitos']
      },
    },
  },

  validarCompatibilidad(estilo: string, musica?: string, narrativa?: string) {
    const config = this.estilos[estilo.toUpperCase() as keyof typeof this.estilos];
    if (!config) {
      return { 
        status: false, 
        motivo: `ESTILO_DESCONOCIDO: El estilo '${estilo}' no existe en los registros.` 
      };
    }

    if (musica) {
      if ((config as any).restricciones?.musicaProhibida?.includes(musica)) {
        return { 
          status: false, 
          motivo: `COLISIÓN_ESTÉTICA: La música '${musica}' rompe la atmósfera '${estilo}'.` 
        };
      }
    }

    if (narrativa) {
      const palabrasClave = narrativa.toLowerCase().split(' ');
      const esCoherente = config.narrativa.some(palabra => palabrasClave.includes(palabra));
      
      if (!esCoherente) {
        return { 
          status: false, 
          motivo: `ERROR_NARRATIVO: El tono de la IA no coincide con la ontología '${estilo}'.` 
        };
      }
    }

    return { status: true, msg: 'Coherencia confirmada.' };
  }
};

export class InferenceBridge {
  tensionMap = new Map<string, number>();

  async observeBehavior(worldId: string, payload: any, wasAccepted: boolean) {
    const config = WorldOntology.estilos[worldId as keyof typeof WorldOntology.estilos];
    if (!config) return null;

    const tension = this.tensionMap.get(worldId) || 0;
    // Threshold is inversely proportional to stability: lower stability = faster mutation
    const threshold = 15 * (1.1 - config.estabilidad); 
    
    if (!wasAccepted || payload.forceOverride) {
      const increment = payload.forceOverride ? 1.5 : 1.0;
      const newTension = tension + increment;
      this.tensionMap.set(worldId, newTension);
      
      if (newTension >= threshold) {
        return {
          action: 'SUGGEST_MUTATION',
          worldId,
          proposal: {
            addAllowed: payload.prompt?.includes('music') ? "Techno-Hybrid" : "Evolved-Logic",
            explanation: `High semantic tension (${newTension.toFixed(1)}/${threshold.toFixed(1)}) in ${worldId}. The ontology is cracking under user pressure. Proposing structural adaptation.`
          }
        };
      }
    } else {
      if (tension > 0) this.tensionMap.set(worldId, Math.max(0, tension - (0.1 * config.estabilidad)));
    }
    return null;
  }

  async applyMutation(worldId: string, proposal: any) {
    const config = WorldOntology.estilos[worldId as keyof typeof WorldOntology.estilos];
    if (config) {
      config.musicaPermitida.push(proposal.addAllowed);
      config.narrativa.push("mutated", "adaptive");
      // Slight stability drop after mutation
      config.estabilidad = Math.max(0.5, config.estabilidad - 0.05);
    }
    this.tensionMap.set(worldId, 0);
    return { status: 'MUTATED' };
  }
}

export const BridgeInstance = new InferenceBridge();

export const SemanticValidatorEngine = {
  async validateAndAdjust(request: { estilo: string; comando: string; payload: any }) {
    const { estilo, comando, payload } = request;
    const config = WorldOntology.estilos[estilo as keyof typeof WorldOntology.estilos];

    if (!config) return { action: 'REJECT', reason: 'ESTILO_INVALIDO' };

    if (comando === 'generar_musica') {
      const validacion = WorldOntology.validarCompatibilidad(estilo, payload.genero);
      if (!validacion.status) {
        if (payload.forceOverride) {
          return { 
            action: 'PROCEED', 
            warning: "Disonancia permitida por el usuario. Registrando inestabilidad.",
            adjustedPayload: payload 
          };
        }
        return { 
          action: 'REJECT', 
          reason: validacion.motivo,
          suggestion: config.musicaPermitida[0]
        };
      }
    }

    if (comando === 'generar_texto' || comando === 'generar_imagen') {
      payload.prompt = `[ONTOLOGY_ID: ${config.id}][STABILITY: ${config.estabilidad}][NARRATIVE_SEED: ${config.narrativa.join(', ')}] ${payload.prompt}`;
    }

    return { action: 'PROCEED', adjustedPayload: payload };
  }
};

export const ArquiRouter = {
  async procesar(request: { comando: string; contexto: { worldId: string; payload: any } }) {
    const { comando, contexto } = request;

    const validacion = await SemanticValidatorEngine.validateAndAdjust({
      estilo: contexto.worldId,
      comando: comando,
      payload: contexto.payload
    });

    if (validacion.action === 'REJECT') {
      return {
        status: "FALLO_SEMANTICO",
        msg: validacion.reason,
        help: `Override suggested to adapt the Arkhé core.`
      };
    }

    return {
      status: "READY",
      payload: validacion.adjustedPayload,
      meta: validacion.warning || "Coherencia nominal"
    };
  }
};
