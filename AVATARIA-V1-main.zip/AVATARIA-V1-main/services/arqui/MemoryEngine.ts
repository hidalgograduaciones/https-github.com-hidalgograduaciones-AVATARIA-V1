import { MemoryData } from '../../types';

export const MemoryEngine = {
  data: {
    salon: null,
    mobiliario: []
  } as MemoryData,

  set(clave: string, valor: any) {
    this.data[clave] = valor;
    this.save();
  },

  push(clave: string, valor: any) {
    if (!this.data[clave]) this.data[clave] = [];
    if (Array.isArray(this.data[clave])) {
        this.data[clave].push(valor);
    }
    this.save();
  },

  save() {
    try {
        localStorage.setItem("arqui_memoria", JSON.stringify(this.data));
    } catch (e) {
        console.warn("Error saving memory", e);
    }
  },

  load() {
    try {
        const data = localStorage.getItem("arqui_memoria");
        if (data) this.data = JSON.parse(data);
    } catch (e) {
        console.warn("Error loading memory", e);
    }
  }
};

// Initialize load on import
MemoryEngine.load();