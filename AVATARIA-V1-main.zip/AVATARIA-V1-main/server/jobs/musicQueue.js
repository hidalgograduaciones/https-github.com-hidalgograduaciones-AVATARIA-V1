
import { Queue, Worker } from 'bullmq';
import { v4 as uuidv4 } from 'uuid';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import IORedis from "ioredis";
import axios from "axios";
import { validateAudio } from '../services/audioValidator.js';
import { writeTrackMetadata } from '../services/trackDNA.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const redisConfig = process.env.REDIS_URL || {
  host: "127.0.0.1",
  port: 6379,
  maxRetriesPerRequest: null,
  retryStrategy: (times) => Math.min(times * 100, 2000)
};

const connection = new IORedis(redisConfig);
connection.on('error', () => {}); 

export const musicQueue = new Queue('music-generation', { 
    connection,
    defaultJobOptions: { removeOnComplete: 50, removeOnFail: 100 }
});

export const createMusicJob = async (data) => {
  const jobId = uuidv4();
  const timeout = new Promise((_, reject) => 
    setTimeout(() => reject(new Error("REDIS_TIMEOUT")), 3500)
  );

  try {
    const addJob = musicQueue.add('generate-music', data, { jobId });
    await Promise.race([addJob, timeout]);
    return jobId;
  } catch (error) {
    console.error("[Queue] Error al crear job:", error.message);
    throw new Error(error.message === "REDIS_TIMEOUT" ? "REDIS_OFFLINE" : "QUEUE_ERROR");
  }
};

export const musicWorker = new Worker(
  'music-generation',
  async (job) => {
    const { prompt, style = '', duration = 10 } = job.data;
    const ENGINE_URL = process.env.AUDIO_ENGINE_URL || 'http://127.0.0.1:5005';

    try {
        await axios.post(`${ENGINE_URL}/generate`, {
            prompt: `${prompt} ${style}`,
            duration,
            job_id: job.id
        });

        const outPath = path.resolve(__dirname, `../storage/tracks/${job.id}/track.wav`);
        
        let retries = 10;
        while (!fs.existsSync(outPath) && retries > 0) {
            await new Promise(r => setTimeout(r, 1000));
            retries--;
        }

        if (!fs.existsSync(outPath)) throw new Error('Generation timeout: File not found');

        const isValid = await validateAudio(outPath);
        if (!isValid) throw new Error('Audio validation failed');

        writeTrackMetadata(job.id, { prompt, style, duration });

        return { audioPath: `/api/tracks/${job.id}/track.wav` };
    } catch (error) {
        console.error(`[Worker] Job ${job.id} failed:`, error.message);
        throw error;
    }
  },
  { connection }
);
