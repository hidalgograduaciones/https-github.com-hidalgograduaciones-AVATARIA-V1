// DEPRECATED
// Use libs/arqui/arqui-core instead.
// This file is kept as a placeholder to prevent import errors during migration.

export const Arqui = {
  procesar: () => {
    console.warn("Using deprecated Arqui service. Please migrate to libs/arqui/arqui-core.");
    return { resultado: "DEPRECATED_SERVICE", identidad: "OLD" };
  }
};