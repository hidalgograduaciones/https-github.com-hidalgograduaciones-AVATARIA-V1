import express from "express";
import cors from "cors";
import path from "path";
import { fileURLToPath } from "url";
import arquiRoutes from './routes/arquiController.js';
import tracksRoutes from './routes/tracks.js';
import healthRoutes from './routes/health.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json({ limit: "50mb" }));
app.use(cors({ origin: "*", methods: ["GET", "POST"] }));

// Mount Routes
app.use('/api/arqui', arquiRoutes); // /api/arqui/command, /api/arqui/job/:id
app.use('/api', tracksRoutes);      // /api/tracks/..., /api/export/...
app.use('/api', healthRoutes);      // /api/health

// Basic Error Handling
app.use((err, req, res, next) => {
  console.error('[Server Error]', err);
  res.status(500).json({ status: 'ERROR', message: 'Internal Server Error' });
});

const PORT = process.env.PORT || 3001;

// Bind to all interfaces to ensure accessibility
app.listen(PORT, '0.0.0.0', () => {
  console.log(`🧠 OmniSound Core running on http://127.0.0.1:${PORT}`);
});
