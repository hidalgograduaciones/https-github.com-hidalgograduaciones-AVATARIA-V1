export const StabilityCore = {
  stable: true,
  enforce(respuesta: string | undefined | null): string {
    if (!respuesta) return "Operación completada.";
    return respuesta.trim();
  }
};