import express from 'express';
import { systemHealth } from '../services/healthcheck.js';

const router = express.Router();

router.get('/health', async (_, res) => {
  const status = await systemHealth();
  if (status.all) return res.json({ status: 'HEALTHY', ...status });
  return res.status(500).json({ status: 'UNHEALTHY', ...status });
});

export default router;
