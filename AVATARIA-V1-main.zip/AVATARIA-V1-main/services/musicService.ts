import axios from 'axios';

export type GenerateMusicPayload = {
  userId: string;
  prompt: string;
  duration: number;
};

export type JobPhase =
  | 'SYNCING'
  | 'SEEDING'
  | 'COMPOSING'
  | 'MASTERING'
  | 'FINALIZING';

export type ArquiJobStatus = 'ACCEPTED' | 'RUNNING' | 'SUCCESS' | 'ERROR';

export type MusicJobResponse = {
  status: ArquiJobStatus;
  jobId: string;
  phase: JobPhase;
  progress: number;
  cost?: {
    omniCoins: number;
  };
  data?: {
    audioUrl: string;
    metadata: {
      duration: number;
      provider: string;
      generatedAt: string;
    };
  };
  error?: {
    code: string;
    message: string;
  };
};

// --- SIMULATION CORE (Mocking MSW behavior internally for stability) ---
const SIMULATION_MODE = true;
const jobStore: Record<string, MusicJobResponse> = {};

const simulateDelay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

const mockGenerate = async (payload: GenerateMusicPayload): Promise<MusicJobResponse> => {
    await simulateDelay(800); // Network latency
    const jobId = `job-${Date.now()}`;
    
    // Initial State
    jobStore[jobId] = {
        status: 'ACCEPTED',
        jobId,
        phase: 'SYNCING',
        progress: 0,
        cost: { omniCoins: 12 }
    };

    // Simulate async processing in background (updating the store)
    let progress = 0;
    const interval = setInterval(() => {
        if (!jobStore[jobId]) { clearInterval(interval); return; }
        
        progress += Math.floor(Math.random() * 15) + 5;
        if (progress > 100) progress = 100;

        let phase: JobPhase = 'SYNCING';
        if (progress > 10) phase = 'SEEDING';
        if (progress > 30) phase = 'COMPOSING';
        if (progress > 70) phase = 'MASTERING';
        if (progress >= 95) phase = 'FINALIZING';

        if (progress >= 100) {
             jobStore[jobId] = {
                ...jobStore[jobId],
                status: 'SUCCESS',
                phase: 'FINALIZING',
                progress: 100,
                data: {
                    audioUrl: 'https://assets.mixkit.co/music/preview/mixkit-synthwave-80s-132.mp3',
                    metadata: {
                        duration: payload.duration,
                        provider: 'OmniSound Core',
                        generatedAt: new Date().toISOString()
                    }
                }
             };
             clearInterval(interval);
        } else {
            jobStore[jobId] = {
                ...jobStore[jobId],
                status: 'RUNNING',
                phase,
                progress
            };
        }
    }, 800);

    return jobStore[jobId];
};

const mockGetJob = async (jobId: string): Promise<MusicJobResponse> => {
    await simulateDelay(300); // Network latency
    const job = jobStore[jobId];
    if (!job) {
        throw new Error("Job not found");
    }
    return job;
};
// -----------------------------------------------------------------------

export const generateMusic = async (
  payload: GenerateMusicPayload
): Promise<MusicJobResponse> => {
  if (SIMULATION_MODE) return mockGenerate(payload);

  const response = await axios.post<MusicJobResponse>('/arqui/command', {
    command: 'GENERATE_MUSIC',
    payload,
  });
  return response.data;
};

export const getMusicJob = async (
  jobId: string
): Promise<MusicJobResponse> => {
  if (SIMULATION_MODE) return mockGetJob(jobId);

  const response = await axios.get<MusicJobResponse>(`/arqui/job/${jobId}`);
  return response.data;
};