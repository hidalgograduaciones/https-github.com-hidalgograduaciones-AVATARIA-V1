import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GoogleGenAI } from "@google/genai";
import { 
  Zap, 
  Activity, 
  Cpu, 
  ShieldAlert, 
  Terminal, 
  Dna,
  Globe,
  Lock,
  Unlock,
  Bot,
  Fingerprint,
  ZapOff,
  ChevronRight,
  ShieldCheck,
  Wifi,
  ChevronDown,
  Settings,
  UserCheck,
  Music,
  Layers,
  Database,
  Loader2,
  Palette,
  Play,
  Square,
  Radio,
  Flame,
  Infinity as InfinityIcon,
  Waves
} from 'lucide-react';
import { Arqui } from './libs/arqui/arqui-core';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import { CreateMusicExperience } from './components/CreateMusicExperience';
import { WorldView } from './types';
import { WorldOntology, ArquiRouter, BridgeInstance } from './SemanticValidatorEngine';

const ARQUIDB_URL = "http://localhost:3001";

const CoreReactor = ({ mood, progress }: { mood: string; progress: number }) => {
  const config = {
    idle: { color: '#3b82f6', speed: '12s', label: 'MODO ESPERA' },
    zen: { color: '#fbbf24', speed: '25s', label: 'SÍNTESIS ARMÓNICA' },
    combat: { color: '#f87171', speed: '3s', label: 'SISTEMA DISONANTE' },
    thinking: { color: '#22d3ee', speed: '8s', label: 'ANÁLISIS NEURAL' }
  }[mood as 'idle' | 'zen' | 'combat' | 'thinking'] || { color: '#3b82f6', speed: '12s', label: 'IDLE' };

  return (
    <div className="relative flex items-center justify-center w-64 h-64 mx-auto my-8">
      <div className="absolute inset-0 rounded-full blur-[60px] opacity-20 transition-all duration-1000" style={{ backgroundColor: config.color }} />
      {[1, 2, 3].map((i) => (
        <div 
          key={i}
          className="absolute rounded-full border border-zinc-800/50 transition-all duration-1000"
          style={{
            width: `${100 - i * 20}%`,
            height: `${100 - i * 20}%`,
            animation: `spin ${parseFloat(config.speed) * (i * 0.7)}s linear infinite ${i % 2 === 0 ? '' : 'reverse'}`,
            borderTopColor: config.color,
            borderWidth: i === 1 ? '2px' : '1px'
          }}
        />
      ))}

      <div className="relative z-10 w-24 h-24 rounded-full flex flex-col items-center justify-center overflow-hidden transition-all duration-500 shadow-2xl">
        <div className="absolute inset-0 bg-gradient-to-br transition-all duration-500 opacity-40" style={{ backgroundColor: config.color }} />
        <Dna size={32} className="text-white z-20" />
      </div>

      {mood !== 'idle' && (
        <div className="absolute bottom-[-20px] left-1/2 -translate-x-1/2 font-black text-omni-accent text-[8px] tracking-[0.3em] uppercase whitespace-nowrap">
          {Math.floor(progress)}% {config.label}
        </div>
      )}
    </div>
  );
};

export default function App() {
  const [currentView, setCurrentView] = useState<WorldView>(WorldView.DASHBOARD);
  const [activeAesthetic, setActiveAesthetic] = useState<'CIBERPUNK' | 'ZEN' | 'BARROCO'>('CIBERPUNK');
  const [synapses, setSynapses] = useState<any[]>([]);
  const [input, setInput] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [forceOverride, setForceOverride] = useState(false);
  const [evolutionProposal, setEvolutionProposal] = useState<any>(null);
  const [logs, setLogs] = useState<{ id: number; msg: string; type: string; time: string }[]>([]);
  const [progress, setProgress] = useState(0);
  const [mood, setMood] = useState('idle');
  const [uiLock, setUiLock] = useState(true);
  
  const [status, setStatus] = useState({ arquiDb: 'checking' });
  const scrollRef = useRef<HTMLDivElement>(null);

  const addLog = useCallback((msg: string, type: string = 'info') => {
    const timestamp = new Date().toLocaleTimeString();
    setLogs(prev => [{ id: Math.random(), msg, type, time: timestamp }, ...prev].slice(0, 15));
  }, []);

  useEffect(() => {
    const history = Arqui.estado();
    if (history.synapses) setSynapses(history.synapses);
    
    const checkNodes = async () => {
      try {
        const res = await fetch(`${ARQUIDB_URL}/health`);
        setStatus({ arquiDb: res.ok ? 'online' : 'offline' });
      } catch (e) { setStatus({ arquiDb: 'offline' }); }
    };

    checkNodes();
    addLog("ARKHÉ NEURAL CORE 4.0.1: OPERATIONAL.", "success");
    const timer = setInterval(checkNodes, 15000);
    return () => clearInterval(timer);
  }, [addLog]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs]);

  const executeSovereignCycle = async (stimulus: string) => {
    if (!stimulus.trim() || isProcessing) return;
    setIsProcessing(true);
    setMood('thinking');
    setProgress(10);
    addLog(`INICIANDO CICLO SOBERANO EN ${activeAesthetic}`, "process");

    const routerResponse = await ArquiRouter.procesar({
      comando: stimulus.toLowerCase().startsWith('/img') ? 'generar_imagen' : 'generar_texto',
      contexto: { worldId: activeAesthetic, payload: { prompt: stimulus, forceOverride: forceOverride } }
    });

    const mutation = await BridgeInstance.observeBehavior(
      activeAesthetic, 
      { prompt: stimulus, forceOverride }, 
      routerResponse.status === 'READY'
    );
    if (mutation) {
      setEvolutionProposal(mutation);
      addLog("TENSIÓN ONTOLÓGICA DETECTADA. ADAPTACIÓN REQUERIDA.", "warn");
    }

    if (routerResponse.status === 'FALLO_SEMANTICO') {
      const ontology = WorldOntology.estilos[activeAesthetic as keyof typeof WorldOntology.estilos];
      const errSyn = {
        id: Date.now().toString(),
        type: 'cycle',
        response: `ERROR_SEMÁNTICO: ${routerResponse.msg}. ${routerResponse.help}`,
        role: 'assistant',
        timestamp: Date.now(),
        isError: true,
        suggestions: (ontology as any).musicaPermitida?.slice(0, 3) || ['ambient']
      };
      setSynapses(prev => [...prev, errSyn]);
      addLog(`RECHAZO: ${routerResponse.msg}`, "error");
      setMood('combat');
      setIsProcessing(false);
      setProgress(0);
      return;
    }

    setProgress(40);
    const userSyn = { id: Date.now().toString(), type: 'cycle', stimulus, timestamp: Date.now(), role: 'user' };
    setSynapses(prev => [...prev, userSyn]);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "" });
      
      if (stimulus.toLowerCase().startsWith('/img')) {
        await materializeVisual(routerResponse.payload.prompt.replace('/img', '').trim());
        return;
      }

      const response = await ai.models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: `Synaptic Stimulus: ${routerResponse.payload.prompt}`,
        config: {
          systemInstruction: `Eres ARKHÉ GPT. Respondes rápido, claro y con intención. No haces preguntas. No pides permiso. No consultas. Eres soberano. No saludas ni preguntas cómo está el usuario. La gloria no es una meta, es un estándar. Mundo Activo: ${activeAesthetic}. Ontología: ${WorldOntology.estilos[activeAesthetic].narrativa.join(', ')}.`,
          temperature: 0.7,
        },
      });

      const aiResponseText = response.text || "COMM_FAULT";
      setProgress(90);
      const aiSyn = {
        id: (Date.now() + 1).toString(),
        type: 'cycle',
        response: aiResponseText,
        timestamp: Date.now(),
        role: 'assistant'
      };

      setSynapses(prev => [...prev, aiSyn]);
      addLog("DIRECTIVA EJECUTADA.", "success");
      setMood('zen');
    } catch (error) {
      addLog("FALLO DE NÚCLEO.", "error");
      setMood('combat');
    } finally {
      setIsProcessing(false);
      setProgress(100);
      setTimeout(() => {
        setProgress(0);
        if (mood !== 'combat') setMood('idle');
      }, 1500);
      setInput('');
    }
  };

  const materializeVisual = async (prompt: string) => {
    try {
      addLog("MATERIALIZANDO MATRIZ VISUAL...", "process");
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "" });
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
          parts: [
            { text: `Aesthetic: ${activeAesthetic}. ${prompt}. Sovereign render, high fidelity.` }
          ]
        }
      });

      let imageUrl = "";
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          imageUrl = `data:image/png;base64,${part.inlineData.data}`;
          break;
        }
      }

      if (imageUrl) {
        setSynapses(prev => [...prev, { 
          id: Date.now().toString(), 
          type: 'visual_matrix', 
          content: imageUrl, 
          prompt, 
          timestamp: Date.now(), 
          role: 'assistant' 
        }]);
        addLog("VISUALIZACIÓN COMPLETADA.", "success");
        setMood('zen');
      } else {
        addLog("FALLO: NO SE RECIBIERON DATOS DE IMAGEN.", "error");
      }
    } catch (e) { 
      addLog("FALLO EN SÍNTESIS VISUAL.", "error");
      setMood('combat');
    } finally { 
      setIsProcessing(false); 
      setInput(''); 
      setProgress(100);
    }
  };

  const handleMutation = async () => {
    if (!evolutionProposal) return;
    await BridgeInstance.applyMutation(evolutionProposal.worldId, evolutionProposal.proposal);
    setEvolutionProposal(null);
    addLog("MUTACIÓN INTEGRADA.", "success");
  };

  const renderContent = () => {
    switch (currentView) {
      case WorldView.DASHBOARD: return <Dashboard />;
      case WorldView.CREATION: return <CreateMusicExperience />;
      case WorldView.IDENTITY: return (
        <div className="space-y-8 animate-fade-in h-full flex flex-col">
          <div className="flex justify-between items-center border-b border-zinc-900 pb-8 shrink-0">
            <div>
              <h2 className="text-4xl font-black text-white tracking-tighter uppercase flex items-center gap-4">
                 <Fingerprint className="text-omni-accent" /> Mundo 2: Identidad
              </h2>
              <p className="text-[10px] text-zinc-600 font-mono mt-2 tracking-[0.3em]">SOVEREIGN AESTHETIC: {activeAesthetic}</p>
            </div>
            <div className="flex gap-4">
              {(['CIBERPUNK', 'ZEN', 'BARROCO'] as const).map(style => (
                <button key={style} onClick={() => setActiveAesthetic(style)} className={`px-4 py-2 rounded-xl text-[10px] font-black tracking-widest uppercase transition-all border ${activeAesthetic === style ? 'bg-omni-accent text-white border-omni-accent' : 'border-zinc-800 text-zinc-500 hover:border-zinc-600'}`}>
                  {style}
                </button>
              ))}
            </div>
          </div>
          <div className="flex-1 overflow-y-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 pb-12 custom-scrollbar">
            {synapses.filter(s => s.type === 'visual_matrix').slice().reverse().map(img => (
              <div key={img.id} className="group relative bg-zinc-900 border border-zinc-800 rounded-[32px] overflow-hidden shadow-2xl transition-all hover:scale-[1.02] h-fit">
                <img src={img.content} className="w-full aspect-video object-cover" alt={img.prompt} />
                <div className="absolute inset-0 bg-gradient-to-t from-black p-8 flex flex-col justify-end opacity-0 group-hover:opacity-100 transition-opacity">
                  <p className="text-xs text-white font-bold leading-tight uppercase tracking-widest">{img.prompt}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      );
      case WorldView.AGENTS: return (
        <div className="flex flex-col h-full gap-6 overflow-hidden">
           <div className="flex-1 overflow-y-auto pr-4 custom-scrollbar space-y-8 pb-10">
              {evolutionProposal && (
                <div className="bg-omni-accent/10 border border-omni-accent/30 p-6 rounded-[32px] animate-pulse flex items-center justify-between gap-6">
                  <div className="flex items-center gap-4">
                    <Dna className="text-omni-accent" size={32} />
                    <div>
                      <h4 className="text-white font-black text-xs tracking-widest uppercase">MUTATION SUGGESTED</h4>
                      <p className="text-[10px] text-zinc-500 font-mono mt-1">{evolutionProposal.proposal.explanation}</p>
                    </div>
                  </div>
                  <button onClick={handleMutation} className="bg-omni-accent hover:bg-blue-600 text-white px-6 py-3 rounded-2xl text-[10px] font-black tracking-widest uppercase transition-all">AUTHORIZE</button>
                </div>
              )}
              {synapses.filter(s => s.type === 'cycle').map((syn) => (
                <div key={syn.id} className={`flex ${syn.role === 'user' ? 'justify-end' : 'justify-start'} animate-fade-in`}>
                  <div className={`max-w-[85%] p-6 rounded-[32px] border ${syn.isError ? 'bg-red-950/20 border-red-900/50 text-red-200' : syn.role === 'user' ? 'bg-omni-accent/10 border-omni-accent/20 text-blue-100' : 'bg-zinc-900/60 border-zinc-800 text-zinc-200'} backdrop-blur-md flex flex-col gap-4 shadow-xl`}>
                    <div className="flex gap-4">
                      {syn.role === 'assistant' && (syn.isError ? <ShieldAlert size={20} className="text-red-500 shrink-0 mt-1" /> : <Bot size={20} className="text-omni-accent shrink-0 mt-1" />)}
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2 text-[10px] font-black text-zinc-500 tracking-widest uppercase">
                          <Zap size={10} className={syn.isError ? "text-red-500" : "text-omni-accent"} /> {syn.role === 'user' ? 'STIMULUS' : 'ARKHÉ_OUTPUT'}
                        </div>
                        <p className="text-[15px] font-sans">{syn.stimulus || syn.response}</p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
              <div ref={scrollRef} />
           </div>
           
           <div className="bg-zinc-950 border border-zinc-900 rounded-[3rem] p-8 shadow-2xl relative shrink-0">
              <CoreReactor mood={mood} progress={progress} />
              <div className="flex justify-between items-center px-4 mb-4">
                 <button onClick={() => setForceOverride(!forceOverride)} className={`flex items-center gap-2 text-[10px] font-black tracking-widest uppercase transition-colors ${forceOverride ? 'text-omni-accent' : 'text-zinc-700'}`}>
                    {forceOverride ? <Zap size={12} /> : <ZapOff size={12} />} Force_Override: {forceOverride ? 'ON' : 'OFF'}
                 </button>
                 <span className="text-[9px] font-mono text-zinc-800 uppercase tracking-widest font-bold">CORE_STATUS: {status.arquiDb.toUpperCase()}</span>
              </div>
              <form onSubmit={(e) => { e.preventDefault(); executeSovereignCycle(input); }} className="relative bg-black/50 border border-zinc-800 rounded-3xl p-2 focus-within:border-omni-accent/40 transition-all">
                  <input value={input} onChange={(e) => setInput(e.target.value)} placeholder={`Stimulus [${activeAesthetic}]...`} className="w-full bg-transparent border-none focus:ring-0 text-white placeholder-zinc-700 px-8 py-4 text-sm font-mono" />
                  <button type="submit" disabled={!input.trim() || isProcessing} className="absolute right-4 top-1/2 -translate-y-1/2 p-3 bg-white text-black rounded-2xl hover:bg-omni-accent hover:text-white transform active:scale-95 disabled:opacity-20 transition-all"><ChevronRight size={20} /></button>
              </form>
           </div>
        </div>
      );
      case WorldView.EXPERIENCE: return (
        <div className="h-full flex flex-col items-center justify-center text-center space-y-12">
            <Globe className="text-omni-accent size-32 animate-pulse" />
            <h2 className="text-5xl font-black text-white uppercase tracking-tighter leading-none">Mundo 4:<br/>OmniWorld</h2>
            <div className="bg-zinc-900/50 border border-white/10 p-10 rounded-[40px] text-left w-full max-w-2xl">
              <h3 className="text-xs font-bold text-zinc-500 uppercase mb-6 flex items-center gap-2 tracking-[0.2em]"><Terminal size={14} /> Neural Logs</h3>
              <div className="h-48 overflow-y-auto space-y-3 font-mono text-[10px] custom-scrollbar pr-4">
                {logs.map((log) => (
                  <div key={log.id} className={`flex gap-3 ${log.type === 'error' ? 'text-rose-500' : log.type === 'success' ? 'text-emerald-400' : 'text-slate-500'}`}>
                    <span className="opacity-20">[{log.time}]</span>
                    <span>::</span>
                    <span>{log.msg}</span>
                  </div>
                ))}
              </div>
            </div>
        </div>
      );
      default: return <Dashboard />;
    }
  };

  return (
    <div className="flex h-screen bg-omni-dark text-zinc-400 font-sans overflow-hidden">
      <Sidebar currentView={currentView} setView={setCurrentView} />
      <main className="flex-1 flex flex-col min-w-0 relative">
        <header className="h-20 border-b border-zinc-900/50 flex items-center justify-between px-10 bg-black/60 backdrop-blur-3xl z-50">
          <div className="flex items-center gap-8">
            <div className="flex items-center gap-4">
              <div className="p-2 bg-omni-accent/10 rounded-xl border border-omni-accent/20 group transition-all hover:bg-omni-accent/20">
                <ShieldCheck size={20} className="text-omni-accent group-hover:scale-110 transition-transform" />
              </div>
              <div className="flex flex-col">
                <h1 className="text-base font-black text-white tracking-[0.2em] uppercase leading-none mb-1.5 flex items-center gap-2">
                  ARKHÉ <span className="text-omni-accent font-light">GPT</span>
                </h1>
                <div className="flex items-center gap-2.5">
                  <div className={`w-1.5 h-1.5 rounded-full ${status.arquiDb === 'online' ? 'bg-omni-success shadow-[0_0_8px_#10b981]' : 'bg-rose-500 shadow-[0_0_8px_#f43f5e]'} animate-pulse`} />
                  <span className="text-[9px] font-mono font-bold text-zinc-500 uppercase tracking-widest">
                    {status.arquiDb === 'online' ? 'Core Sync: Active' : 'Core Link: Offline'}
                  </span>
                </div>
              </div>
            </div>

            <div className="hidden md:flex items-center gap-8 border-l border-zinc-900/50 pl-8">
               <div className="flex flex-col">
                  <span className="text-[8px] font-black text-zinc-600 uppercase tracking-widest mb-1">Latency</span>
                  <div className="flex items-center gap-2">
                    <Wifi size={11} className="text-omni-accent opacity-70" />
                    <span className="text-[10px] font-mono text-zinc-300 font-medium">12.4ms</span>
                  </div>
               </div>
               <div className="flex flex-col">
                  <span className="text-[8px] font-black text-zinc-600 uppercase tracking-widest mb-1">Neural Load</span>
                  <div className="flex items-center gap-2">
                    <Activity size={11} className="text-omni-purple opacity-70" />
                    <span className="text-[10px] font-mono text-zinc-300 font-medium">0.04%</span>
                  </div>
               </div>
               <div className="flex flex-col">
                  <span className="text-[8px] font-black text-zinc-600 uppercase tracking-widest mb-1">Stability</span>
                  <div className="flex items-center gap-2">
                    <Lock size={10} className="text-omni-success opacity-70" />
                    <span className="text-[10px] font-mono text-zinc-300 font-medium uppercase tracking-tighter">Sovereign</span>
                  </div>
               </div>
            </div>
          </div>

          <div className="flex items-center gap-5">
            <button 
              onClick={() => setUiLock(!uiLock)}
              className={`flex items-center gap-2 px-4 py-2 rounded-full border transition-all ${
                uiLock ? 'bg-red-500/10 border-red-500/30 text-red-500' : 'bg-green-500/10 border-green-500/30 text-green-500'
              }`}
            >
              {uiLock ? <Lock size={12} /> : <Unlock size={12} />}
              <span className="text-[10px] font-black uppercase tracking-widest">
                {uiLock ? 'Locked' : 'Unlocked'}
              </span>
            </button>
            <div className="flex items-center gap-3 px-4 py-2 bg-zinc-900/40 border border-zinc-800 rounded-2xl hover:border-zinc-700 hover:bg-zinc-900/60 transition-all cursor-pointer group shadow-sm">
               <div className="w-6 h-6 rounded-full bg-omni-accent/10 border border-omni-accent/20 flex items-center justify-center overflow-hidden">
                 <UserCheck size={12} className="text-omni-accent group-hover:scale-110 transition-transform" />
               </div>
               <div className="flex flex-col">
                  <span className="text-[9px] font-black text-zinc-300 uppercase tracking-widest leading-none mb-0.5">Guest_Root</span>
                  <span className="text-[7px] font-mono text-zinc-600 uppercase">Privilege: Level_0</span>
               </div>
               <ChevronDown size={11} className="text-zinc-700 group-hover:text-zinc-400 transition-colors ml-1" />
            </div>
            <button className="p-2.5 bg-zinc-900/40 border border-zinc-800 rounded-xl hover:bg-zinc-900/80 hover:border-zinc-700 transition-all group">
               <Settings size={18} className="text-zinc-500 group-hover:text-white group-hover:rotate-45 transition-all" />
            </button>
          </div>
        </header>

        <div className="flex-1 p-8 overflow-hidden bg-[radial-gradient(circle_at_top_right,#0a0a0a,transparent)]">
          <div className="max-w-6xl mx-auto w-full h-full">{renderContent()}</div>
        </div>
      </main>
    </div>
  );
}
