export interface ArquiResponse {
  resultado: string;
  identidad?: string;
  __arqui_identity?: string;
}

export interface MemoryData {
  salon: any;
  mobiliario: any[];
  [key: string]: any;
}

export enum WorldView {
  DASHBOARD = 'DASHBOARD',
  CREATION = 'CREATION',       // Mundo 1: OmniSound (Creación)
  IDENTITY = 'IDENTITY',       // Mundo 2: Génesis (Identidad)
  AGENTS = 'AGENTS',           // Mundo 3: Arkhé (Agentes)
  EXPERIENCE = 'EXPERIENCE'    // Mundo 4: OmniWorld (Experiencia)
}